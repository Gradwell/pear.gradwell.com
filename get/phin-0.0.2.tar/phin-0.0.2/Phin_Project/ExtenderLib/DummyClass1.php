<?php

namespace Phin_Project\ExtenderLib;

class DummyClass1
{
        
}