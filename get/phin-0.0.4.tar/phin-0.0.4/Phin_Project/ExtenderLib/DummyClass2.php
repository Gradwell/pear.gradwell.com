<?php

namespace Phin_Project\ExtenderLib;

$testVar = 'trout';

class DummyClass2
{
        
}