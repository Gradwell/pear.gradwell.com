<?php

namespace Gradwell\ExtenderLib;

class DummyClass1
{
        
}