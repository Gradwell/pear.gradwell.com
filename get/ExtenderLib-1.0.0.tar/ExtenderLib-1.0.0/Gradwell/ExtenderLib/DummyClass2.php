<?php

namespace Gradwell\ExtenderLib;

$testVar = 'trout';

class DummyClass2
{
        
}